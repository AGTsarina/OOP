#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "qcustomplot.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    lines = new QStringList{"First", "Second", "Third"};
    model = new QStringListModel(*lines);
    ui->listView->setModel(model);
    connect(ui->addButton, &QPushButton::clicked,this, &MainWindow::addLine);
    connect(ui->deleteButton, &QPushButton::clicked,this, &MainWindow::deleteLine);
    connect(ui->changeButton, &QPushButton::clicked,this, &MainWindow::change);
    QCustomPlot *plot = new QCustomPlot(this);

    this->ui->frame->layout()->addWidget(plot);
}

void MainWindow::addLine(){
    lines->append(ui->lineEdit->text());
    if (model) delete model;
    model = new QStringListModel(*lines);
    ui->listView->setModel(model);
}

void MainWindow::deleteLine(){
    lines->erase(lines->begin());
    if (model) delete model;
    model = new QStringListModel(*lines);
    ui->listView->setModel(model);
}

void MainWindow::change(){
    for(int i=0; i<lines->size(); i++){
        (*lines)[i] += " line";
    }
    if (model) delete model;
    model = new QStringListModel(*lines);
    ui->listView->setModel(model);
}

MainWindow::~MainWindow()
{
    delete ui;
    delete lines;
    delete model;
}

